#ifndef TEXT_H
#define TEXT_H

#define BLANK "                 "
#define HALF_BLANK "        "

#define GAME_START_LINE1 "   SPEED GAME    "
#define GAME_START_LINE2 " HIGH : "

#define START_LINE1 "   START!        "

#define GAME_LINE1 " = "
#define GAME_LINE2 "SCORE : "

#define GAME_OVER_LINE1 "   GAME OVER!     "


#endif // !TEXT_H
