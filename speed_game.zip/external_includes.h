#ifndef EXTERNAL_INCLUDES_H
#define EXTERNAL_INCLUDES_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

#include <pthread.h>
#include <unistd.h>
#include <sys/mman.h>
#include <unistd.h>


#endif // !EXTERNAL_INCLUDES_H
